
$(document).ready(function(){
	
	//logo page index
	$(".logo-index").hide();
	$(".logo-index").show(function(){
		$(".logo-index").animate({marginTop: '243px'},2000)
			
	});
	
	//*****************************************************************
	
	//prenom page index
	$(".prenom").hide(function(){
		$(".prenom").slideDown(2000);
	
	});
	
	//*****************************************************************
	
	// mon logo de la page d'acceuil
	$('.ma-photo').hide();
	$('.ma-photo').slideDown(1500);
	
	//*****************************************************************
	
	// cache les le soulignage du menu
	$('.hr1').hide();
	$('.hr2').hide();
	
	//*****************************************************************
	
	// survole du menu et affiche le soulignage d'identité visuelle
	$('.underline').mouseenter(
		function(){$('.p1').animate({color:"#00b8ff"});}
		//function(){$('.hr1').show(1000)},	
		//function(){$('.hr1').hide();
    )
	
	$('.underline').mouseleave(
		function(){$('.p1').animate({color:"white"});}
		//function(){$('.hr1').show(1000)},	
		//function(){$('.hr1').hide();
    )
	
	$('.underline2').mouseenter(
		function(){$('.p2').animate({color:"#00b8ff"});}
	)
	
	$('.underline2').mouseleave(
		function(){$('.p2').animate({color:"white"});}
	)
	
	//*****************************************************************
	
	// survole du menu et affiche le soulignage de print
	//$('.p2').hover(
		//function(){$('.hr2').show(1000)},
		//function(){$('.hr2').hide();
	//})
	
	$('.underline2').mouseenter(
		function(){$('.p2').animate({color:"#00b8ff"});}
		
    )
	
	$('.underline2').mouseleave(
		function(){$('.p2').animate({color:"white"});}
		
    )
	
	//*****************************************************************
	
	// au clique dur la bouton bleu, une ligne sélargie pour atteindre 100% la largeur de l'écran et déroule ma présentation$
	$('.fleche-bleu').hide();
	$('.paragraphe').hide();
	$('.div-fleche-bleu').hide();
	$('.progress').hide();
	$('.competence').hide();
	$('.intro').hide();
	$('.johanna').hide();
	$('.johanna-1').hide();
	$('.johanna-2').hide();
	$('.btn-logos').hide();
	$('.fleche-bleu-1').hide();
	$('.fleche-bleu-2').hide();
	$('.affiche').hide();
	$('.affiche-1').hide();
	$('.affiche-2').hide();
	$('.btn-logos-1').hide();
	$('.trait-neons').click(function(){
		$('.trait-neons').animate({width:'100%', fontSize: '0em'},2000)
		$('.presentation').animate({height:'755px'},4000);
		$('.fleche-bleu').fadeIn(5000)
		$('.intro').fadeIn(5000);
		
	});
	
	// au clique sur le bouton fleche bleu les éléments defiles
	
	
	$('.fleche-bleu').click(
	function(){$('.fleche-bleu').animate();
		$('.paragraphe').show(3000);
		$('.intro').hide(2000);
		$('.fleche-bleu').click(
	function(){$('.fleche-bleu').animate();
			$('.progress').show(3000);
			$('.paragraphe').hide();
			$('.competence').show(2000);
	$('.fleche-bleu').click(function() {
     $('html,body').animate({scrollTop: $(".deuxieme-section").offset().top}, 'fast');
		$('.bande-bleu').animate({width:"100%"},3000);
		$('.bande-jaune').animate({width:"100%"},3000);
		$('.johanna').slideDown(2500);
		$('.johanna-1').slideDown(2500);
		$('.johanna-2').slideDown(2500);
		$('.btn-logos').slideDown(2500);
		$('.fleche-bleu-1').fadeIn(2000);
		$('.paragraphe').hide();
		})	   
		
	})
			})
	
	
	$('.fleche-bleu-1').click(
		function(){ $('html,body').animate({scrollTop: $(".troisieme-section").offset().top}, 'fast');
		$('.bande-bleu-1').animate({width:"100%"},3000);
		$('.bande-jaune-1').animate({width:"100%"},3000);
		$('.affiche').slideDown(2500);
		$('.affiche-1').slideDown(2500);
		$('.affiche-2').slideDown(2500);
		$('.affiche-3').slideDown(2500);
		$('.btn-logos-1').slideDown(2500);
		$('.fleche-bleu-2').fadeIn(2000);
	
	})
	
		//$('.fleche-bleu').(
			//function(){$('.fleche-bleu').animate({height:'30px', width:'40px', marginTop:'0px'});
			//$('.intro').fadeIn(2000);
			//$('.paragraphe').hide(3000);
			//})
	//*****************************************************************
	$('.div-titre-logo').hide();
	$('.trait-neons-1').click(function(){
		$('.trait-neons-1').animate({width:'100%', fontSize: '0em'},2000)
		$('.div-titre-logo').slideDown(3000);
		
	});
		//$('.bande-bleu-logo').hide();
	$('.bande-bleu-logo').scroll(function() {
  $('.bande-bleu-logo').fadeIn(500);
});
	
	$('.card').hide();
	$('.card').slideDown(2000);
	

});